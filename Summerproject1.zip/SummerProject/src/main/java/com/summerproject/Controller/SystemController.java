package com.summerproject.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.summerproject.entity.Admin;
import com.summerproject.entity.Employee;
import com.summerproject.entity.Printingshop;
import com.summerproject.service.AdminRepository;
import com.summerproject.service.CustomerRepository;
import com.summerproject.service.EmployeeRepository;
import com.summerproject.service.PrintingShopRepository;
import jakarta.servlet.http.HttpSession;

@Controller
public class SystemController {
	
	@Autowired
	AdminRepository ar;
	
	@Autowired
	EmployeeRepository er;
	
	@Autowired
	PrintingShopRepository psr;
	
	@Autowired
	CustomerRepository cr;
	
	
	
	@RequestMapping("/")
	public String index()
	{
		return"Home";
	}
	
	@RequestMapping("/login")
    public String showLoginPage()
    {
        return "login";
    }
	
	@RequestMapping("/home")
    public String showHome()
    {
        return "Home";
    }
	
	@RequestMapping(value="login", method=RequestMethod.POST)
	public String login(@RequestParam("username") String username,HttpSession session ,@RequestParam("password") String password, ModelMap modelMap)
	{
		Admin admin = ar.findByUsername(username);
		Employee emp = er.findByUsername(username);
		Printingshop ps = psr.findByUsername(username);
		String sid = session.getId();
		if(admin!=null) {
			
			 if(admin.getPassword().equals(password)&&admin.getUsername().equals(username)&&sid!=null)
		        {
				 	
		            modelMap.addAttribute("msg","Welcome "+admin.getUsername());
		            modelMap.addAttribute("name",admin.getUsername());
		            session.setAttribute("username",admin.getUsername());
		            return"redirect:/dashboardadmin";
		        }
		        
		        }
		        if(emp!=null) {
		        	BCryptPasswordEncoder bpe = new BCryptPasswordEncoder();
		       if(bpe.matches(password,emp.getPassword())&&emp.getUsername().equals(username)) {
		    	   modelMap.addAttribute("name",emp.getName());
		    	   session.setAttribute("username",emp.getUsername());	
		    	   return "redirect:/register";
		        }
		       
		        }
		       if(ps!=null) {
		    	   if(ps.getPassword().equals(password)&&ps.getUsername().equals(username)){
		    		   modelMap.addAttribute("name",ps.getUsername());
		    		   session.setAttribute("username",ps.getUsername());	
		    		   return"redirect:/list";
		    	   }
		    	 
		       }
		       modelMap.addAttribute("msg","Username and password are wrong");
		        return "login";
	}
	
	@RequestMapping("logout")
	public String logout(HttpSession session) {
		session.getAttribute("username");
		session.invalidate();
		return "redirect:/login";
	}
	
	
	
}
