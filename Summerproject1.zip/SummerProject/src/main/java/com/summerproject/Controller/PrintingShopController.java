package com.summerproject.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.summerproject.entity.Printed;
import com.summerproject.entity.PrintingPending;
import com.summerproject.service.CustomerRepository;
import com.summerproject.service.PrintedRepository;
import com.summerproject.service.PrintingPendingRepository;
import com.summerproject.service.PrintingShopRepository;

@Controller
public class PrintingShopController {
	@Autowired
	PrintingShopRepository psr;
	
	@Autowired
	CustomerRepository cr;
	
	@Autowired
	PrintedRepository pr;
	
	@Autowired
	PrintingPendingRepository ppr;
	
	@RequestMapping("pending")
	public String list(Model model) {
		List<PrintingPending> p = ppr.findAll();
		 model.addAttribute("customer",p);
		return "list";
	}
	
	@RequestMapping("done")
	public String done(@ModelAttribute("printed")Printed printed,@RequestParam("id") long id,
			@RequestParam("name") String name,@RequestParam("area_no") long area_no,Model map) {
		Printed prs = pr.findById(id);
		if(prs==null) {
		if(printed.getId()==id) {
		pr.save(printed);
		ppr.deleteById(id);
		return "redirect:/list";
		}}
		map.addAttribute("msg","Duplicate customer id");
		return "pending";
		
	}
	
	@RequestMapping("printed")
	public String printed(Model model) {
		List<Printed> printed = pr.findAll();
		model.addAttribute("printed", printed);
		return "printed";
	}
	
	@RequestMapping("addprint")
	public String print() {
		return"addprint";
	}
}
