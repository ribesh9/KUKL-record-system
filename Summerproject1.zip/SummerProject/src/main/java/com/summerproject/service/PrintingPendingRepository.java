package com.summerproject.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.summerproject.entity.PrintingPending;

public interface PrintingPendingRepository extends JpaRepository<PrintingPending,Long>{
	PrintingPending findById(long id);
	PrintingPending findByName(String name);
}
