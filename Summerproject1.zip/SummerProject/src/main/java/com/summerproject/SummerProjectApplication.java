package com.summerproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SummerProjectApplication{

	public static void main(String[] args) {
		SpringApplication.run(SummerProjectApplication.class, args);
	}

}
